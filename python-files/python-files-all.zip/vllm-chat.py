"""
vllm-chat.py — Single-page CLI chat app for a vLLM-served model

Usage:
  python vllm-chat.py
  python vllm-chat.py --url http://localhost:8000 --model Qwen/Qwen3-8B-Instruct
    python vllm-chat.py --url http://localhost:11434 --backend ollama --model qwen3-java:latest
  python vllm-chat.py --system "You are a Java security expert."
  python vllm-chat.py --stream          # enable streaming output
  python vllm-chat.py --no-history      # single-turn mode (no conversation memory)

Special commands (type while chatting):
  /help       show available commands
  /clear      clear conversation history
  /system     show current system prompt
  /system <text>  change system prompt
  /save       save conversation to a file
  /load       load a saved conversation
  /model      show current model name
  /temp <n>   change temperature (e.g. /temp 0.3)
  /tokens <n> change max_tokens (e.g. /tokens 1024)
  /quit  /exit  /q   exit
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import textwrap
import urllib.error
import urllib.request
from datetime import datetime
from pathlib import Path

# ─────────────────────────────────────────────────────────────────────────────
# ANSI colour helpers (gracefully disabled on non-TTY / Windows without VT)
# ─────────────────────────────────────────────────────────────────────────────

def _supports_colour() -> bool:
    if not sys.stdout.isatty():
        return False
    if os.name == "nt":
        try:
            import ctypes
            k32 = ctypes.windll.kernel32
            k32.SetConsoleMode(k32.GetStdHandle(-11), 7)
            return True
        except Exception:
            return False
    return True

USE_COLOUR = _supports_colour()

def _c(code: str, text: str) -> str:
    return f"\033[{code}m{text}\033[0m" if USE_COLOUR else text

def cyan(t):    return _c("36", t)
def green(t):   return _c("32", t)
def yellow(t):  return _c("33", t)
def red(t):     return _c("31", t)
def bold(t):    return _c("1",  t)
def dim(t):     return _c("2",  t)
def magenta(t): return _c("35", t)


# ─────────────────────────────────────────────────────────────────────────────
# vLLM API helpers
# ─────────────────────────────────────────────────────────────────────────────

def _get_models_openai(base_url: str, api_key: str = "") -> list[str]:
    """Return available model names from an OpenAI-compatible /v1/models API."""
    url = f"{base_url.rstrip('/')}/v1/models"
    headers = {"Accept": "application/json"}
    if api_key:
        headers["Authorization"] = f"Bearer {api_key}"
    try:
        req = urllib.request.Request(url, headers=headers)
        with urllib.request.urlopen(req, timeout=10) as r:
            data = json.loads(r.read().decode())
            return [m["id"] for m in data.get("data", [])]
    except Exception:
        return []


def _get_models_ollama(base_url: str) -> list[str]:
    """Return available model tags from Ollama /api/tags."""
    url = f"{base_url.rstrip('/')}/api/tags"
    headers = {"Accept": "application/json"}
    try:
        req = urllib.request.Request(url, headers=headers)
        with urllib.request.urlopen(req, timeout=10) as r:
            data = json.loads(r.read().decode())
            return [m.get("name", "") for m in data.get("models", []) if m.get("name")]
    except Exception:
        return []


def _get_models(base_url: str, api_key: str = "", backend: str = "auto") -> list[str]:
    """Return model names from the selected backend (auto/openai/ollama)."""
    if backend == "openai":
        return _get_models_openai(base_url, api_key)
    if backend == "ollama":
        return _get_models_ollama(base_url)

    models = _get_models_openai(base_url, api_key)
    if models:
        return models
    return _get_models_ollama(base_url)


def _chat_completion_openai(
    base_url: str,
    model: str,
    messages: list[dict],
    temperature: float,
    max_tokens: int,
    stream: bool,
    api_key: str = "",
) -> str:
    """
    Call POST /v1/chat/completions.
    If stream=True, prints tokens as they arrive and returns full text.
    If stream=False, returns full response text.
    """
    url = f"{base_url.rstrip('/')}/v1/chat/completions"
    payload = json.dumps({
        "model":       model,
        "messages":    messages,
        "temperature": temperature,
        "max_tokens":  max_tokens,
        "stream":      stream,
    }).encode()

    headers = {
        "Content-Type": "application/json",
        "Accept":       "text/event-stream" if stream else "application/json",
    }
    if api_key:
        headers["Authorization"] = f"Bearer {api_key}"

    req = urllib.request.Request(url, data=payload, headers=headers, method="POST")

    try:
        with urllib.request.urlopen(req, timeout=300) as resp:
            if not stream:
                data = json.loads(resp.read().decode())
                return data["choices"][0]["message"]["content"]
            else:
                # Stream: print tokens as they arrive
                full_text = ""
                print(green(bold("assistant")) + ": ", end="", flush=True)
                for raw_line in resp:
                    line = raw_line.decode("utf-8").strip()
                    if not line or not line.startswith("data:"):
                        continue
                    chunk_str = line[len("data:"):].strip()
                    if chunk_str == "[DONE]":
                        break
                    try:
                        chunk = json.loads(chunk_str)
                        delta = chunk["choices"][0]["delta"].get("content", "")
                        if delta:
                            print(delta, end="", flush=True)
                            full_text += delta
                    except json.JSONDecodeError:
                        continue
                print()  # newline after stream
                return full_text

    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", errors="ignore")
        raise RuntimeError(f"HTTP {e.code}: {body[:300]}")
    except urllib.error.URLError as e:
        raise RuntimeError(f"Cannot reach {url}: {e.reason}")


def _chat_completion_ollama(
    base_url: str,
    model: str,
    messages: list[dict],
    temperature: float,
    max_tokens: int,
    stream: bool,
) -> str:
    """
    Call Ollama /api/chat.
    If stream=True, prints tokens as they arrive and returns full text.
    If stream=False, returns full response text.
    """
    url = f"{base_url.rstrip('/')}/api/chat"
    payload = json.dumps({
        "model": model,
        "messages": messages,
        "stream": stream,
        "options": {
            "temperature": temperature,
            "num_predict": max_tokens,
        },
    }).encode()

    headers = {
        "Content-Type": "application/json",
        "Accept": "application/json",
    }

    req = urllib.request.Request(url, data=payload, headers=headers, method="POST")

    try:
        with urllib.request.urlopen(req, timeout=300) as resp:
            if not stream:
                data = json.loads(resp.read().decode())
                return data.get("message", {}).get("content", "")

            full_text = ""
            print(green(bold("assistant")) + ": ", end="", flush=True)
            for raw_line in resp:
                line = raw_line.decode("utf-8").strip()
                if not line:
                    continue
                try:
                    chunk = json.loads(line)
                except json.JSONDecodeError:
                    continue

                delta = chunk.get("message", {}).get("content", "")
                if delta:
                    print(delta, end="", flush=True)
                    full_text += delta
                if chunk.get("done", False):
                    break
            print()
            return full_text

    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", errors="ignore")
        raise RuntimeError(f"HTTP {e.code}: {body[:300]}")
    except urllib.error.URLError as e:
        raise RuntimeError(f"Cannot reach {url}: {e.reason}")


def _chat_completion(
    base_url: str,
    model: str,
    messages: list[dict],
    temperature: float,
    max_tokens: int,
    stream: bool,
    api_key: str = "",
    backend: str = "auto",
) -> str:
    """Send chat completion to openai, ollama, or auto backend."""
    if backend == "openai":
        return _chat_completion_openai(
            base_url, model, messages, temperature, max_tokens, stream, api_key
        )

    if backend == "ollama":
        return _chat_completion_ollama(
            base_url, model, messages, temperature, max_tokens, stream
        )

    # auto backend: try OpenAI-compatible endpoint first, then Ollama on 404/405
    try:
        return _chat_completion_openai(
            base_url, model, messages, temperature, max_tokens, stream, api_key
        )
    except RuntimeError as openai_err:
        msg = str(openai_err)
        if "HTTP 404" not in msg and "HTTP 405" not in msg:
            raise
        return _chat_completion_ollama(
            base_url, model, messages, temperature, max_tokens, stream
        )


# ─────────────────────────────────────────────────────────────────────────────
# Text formatting
# ─────────────────────────────────────────────────────────────────────────────

def _wrap_text(text: str, width: int = 100, indent: str = "  ") -> str:
    """Wrap text preserving code blocks and indentation."""
    lines = text.split("\n")
    result = []
    in_code = False

    for line in lines:
        if line.startswith("```"):
            in_code = not in_code
            result.append(line)
            continue
        if in_code:
            result.append(line)
        else:
            if len(line) > width:
                wrapped = textwrap.fill(line, width=width, subsequent_indent=indent)
                result.append(wrapped)
            else:
                result.append(line)

    return "\n".join(result)


def _print_assistant_response(text: str):
    """Print the assistant response with syntax-aware formatting."""
    lines = text.split("\n")
    in_code = False
    code_lang = ""

    for line in lines:
        if line.startswith("```"):
            if not in_code:
                in_code = True
                code_lang = line[3:].strip()
                print(dim(f"  ┌─ {code_lang or 'code'} " + "─" * max(0, 30 - len(code_lang))))
            else:
                in_code = False
                print(dim("  └" + "─" * 33))
        elif in_code:
            print("  " + yellow(line))
        else:
            if line.startswith("**") and line.endswith("**"):
                print(bold(line))
            elif line.startswith("## ") or line.startswith("# "):
                print(bold(cyan(line)))
            else:
                print(line)


# ─────────────────────────────────────────────────────────────────────────────
# Conversation save / load
# ─────────────────────────────────────────────────────────────────────────────

SAVE_DIR = Path("chat_history")

def _save_conversation(messages: list[dict], system: str) -> str:
    SAVE_DIR.mkdir(exist_ok=True)
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    path = SAVE_DIR / f"conversation_{ts}.json"
    with open(path, "w", encoding="utf-8") as f:
        json.dump({"system": system, "messages": messages}, f, indent=2, ensure_ascii=False)
    return str(path)


def _load_conversation(path: str) -> tuple[list[dict], str]:
    with open(path, encoding="utf-8") as f:
        data = json.load(f)
    return data.get("messages", []), data.get("system", "")


# ─────────────────────────────────────────────────────────────────────────────
# Main chat loop
# ─────────────────────────────────────────────────────────────────────────────

HELP_TEXT = """
Available commands:
  /help               show this help
  /clear              clear conversation history (keeps system prompt)
  /system             show current system prompt
  /system <text>      set a new system prompt
  /save               save conversation to chat_history/ folder
  /load <path>        load a saved conversation JSON
  /model              show current model
  /temp <0.0–2.0>     set generation temperature (e.g. /temp 0.2)
  /tokens <n>         set max_tokens per response (e.g. /tokens 2048)
  /stream             toggle streaming on/off
  /history            show conversation history summary
  /quit  /exit  /q    exit
"""

def chat_loop(
    base_url: str,
    model: str,
    system_prompt: str,
    temperature: float,
    max_tokens: int,
    stream: bool,
    keep_history: bool,
    api_key: str,
    backend: str,
):
    conversation: list[dict] = []  # user + assistant turns

    def _build_messages() -> list[dict]:
        msgs = []
        if system_prompt:
            msgs.append({"role": "system", "content": system_prompt})
        if keep_history:
            msgs.extend(conversation)
        return msgs

    # ── Welcome banner ───────────────────────────────────────────────────────
    print()
    print(bold(cyan("━" * 60)))
    print(bold(cyan("  vLLM / Ollama Chat")))
    print(bold(cyan("━" * 60)))
    print(f"  {dim('Server :')} {base_url}")
    print(f"  {dim('Backend:')} {backend}")
    print(f"  {dim('Model  :')} {model}")
    print(f"  {dim('Temp   :')} {temperature}   {dim('Max tokens:')} {max_tokens}")
    print(f"  {dim('Stream :')} {'on' if stream else 'off'}  "
          f"  {dim('History:')} {'on' if keep_history else 'off (single-turn)'}")
    if system_prompt:
        preview = system_prompt[:80].replace("\n", " ")
        print(f"  {dim('System :')} {preview}{'...' if len(system_prompt) > 80 else ''}")
    print(bold(cyan("━" * 60)))
    print(f"  Type {bold('/help')} for commands, {bold('/quit')} to exit.")
    print(bold(cyan("━" * 60)))
    print()

    # ── Check server reachability ────────────────────────────────────────────
    models = _get_models(base_url, api_key, backend)
    if not models:
        print(red(f"[WARN] Could not list models from {base_url}  — is the server running?"))
        print(dim("       Continuing anyway; first request will confirm connectivity."))
    elif model not in models and not any(model in m for m in models):
        print(yellow(f"[WARN] Model '{model}' not in server model list: {models}"))
        print(yellow(f"       Using it anyway — rename with --model if needed."))

    nonlocal_state = {
        "temperature": temperature,
        "max_tokens":  max_tokens,
        "stream":      stream,
        "system":      system_prompt,
    }

    # ── Chat loop ─────────────────────────────────────────────────────────────
    while True:
        try:
            user_input = input(bold(magenta("[user]")) + ": ").strip()
        except (KeyboardInterrupt, EOFError):
            print(f"\n{dim('Interrupted. Type /quit to exit.')}")
            continue

        if not user_input:
            continue

        # ── Handle commands ──────────────────────────────────────────────────
        if user_input.startswith("/"):
            cmd_parts = user_input[1:].split(None, 1)
            cmd = cmd_parts[0].lower()
            arg = cmd_parts[1] if len(cmd_parts) > 1 else ""

            if cmd in ("quit", "exit", "q"):
                print(dim("Goodbye!"))
                break

            elif cmd == "help":
                print(HELP_TEXT)

            elif cmd == "clear":
                conversation.clear()
                print(dim("Conversation history cleared."))

            elif cmd == "system":
                if arg:
                    nonlocal_state["system"] = arg
                    print(dim(f"System prompt updated: {arg[:80]}"))
                else:
                    print(f"System prompt:\n  {nonlocal_state['system'] or dim('(none)')}")

            elif cmd == "save":
                path = _save_conversation(conversation, nonlocal_state["system"])
                print(dim(f"Saved to: {path}"))

            elif cmd == "load":
                if not arg:
                    saved = sorted(SAVE_DIR.glob("*.json")) if SAVE_DIR.exists() else []
                    if saved:
                        print("Available saves:")
                        for i, p in enumerate(saved[-10:]):
                            print(f"  [{i}] {p}")
                        print(dim("  Use: /load <path>"))
                    else:
                        print(dim("No saved conversations found in chat_history/"))
                else:
                    try:
                        msgs, sys_p = _load_conversation(arg)
                        conversation.clear()
                        conversation.extend(msgs)
                        if sys_p:
                            nonlocal_state["system"] = sys_p
                        print(dim(f"Loaded {len(msgs)} messages from {arg}"))
                    except Exception as e:
                        print(red(f"[ERROR] {e}"))

            elif cmd == "model":
                print(f"Model: {model}")
                print(f"Server: {base_url}")

            elif cmd == "temp":
                try:
                    t = float(arg)
                    if 0.0 <= t <= 2.0:
                        nonlocal_state["temperature"] = t
                        print(dim(f"Temperature set to {t}"))
                    else:
                        print(red("Temperature must be between 0.0 and 2.0"))
                except ValueError:
                    print(red(f"Invalid temperature: {arg}"))

            elif cmd == "tokens":
                try:
                    n = int(arg)
                    if n > 0:
                        nonlocal_state["max_tokens"] = n
                        print(dim(f"Max tokens set to {n}"))
                    else:
                        print(red("max_tokens must be > 0"))
                except ValueError:
                    print(red(f"Invalid value: {arg}"))

            elif cmd == "stream":
                nonlocal_state["stream"] = not nonlocal_state["stream"]
                state = "on" if nonlocal_state["stream"] else "off"
                print(dim(f"Streaming {state}"))

            elif cmd == "history":
                if not conversation:
                    print(dim("No history yet."))
                else:
                    print(f"\n{dim('─'*50)}")
                    for i, m in enumerate(conversation):
                        role = m["role"].upper()
                        preview = m["content"][:80].replace("\n", " ")
                        color = magenta if m["role"] == "user" else green
                        print(f"  [{i}] {color(role)}: {preview}{'...' if len(m['content']) > 80 else ''}")
                    print(f"{dim('─'*50)}\n")

            else:
                print(red(f"Unknown command: /{cmd}  (type /help for list)"))

            continue

        # ── Normal message — send to model ───────────────────────────────────
        conversation.append({"role": "user", "content": user_input})
        messages = _build_messages()

        try:
            if nonlocal_state["stream"]:
                # Streaming: tokens printed inside _chat_completion
                response = _chat_completion(
                    base_url    = base_url,
                    model       = model,
                    messages    = messages,
                    temperature = nonlocal_state["temperature"],
                    max_tokens  = nonlocal_state["max_tokens"],
                    stream      = True,
                    api_key     = api_key,
                    backend     = backend,
                )
            else:
                print(dim("  thinking..."), end="\r")
                response = _chat_completion(
                    base_url    = base_url,
                    model       = model,
                    messages    = messages,
                    temperature = nonlocal_state["temperature"],
                    max_tokens  = nonlocal_state["max_tokens"],
                    stream      = False,
                    api_key     = api_key,
                    backend     = backend,
                )
                print(" " * 14, end="\r")  # clear "thinking..."
                print(f"{bold(green('[assistant]'))}: ", end="")
                _print_assistant_response(response)

        except RuntimeError as e:
            conversation.pop()   # remove the user turn we just added
            print(red(f"\n[ERROR] {e}"))
            continue

        # Store assistant response in history
        conversation.append({"role": "assistant", "content": response})

        if not keep_history:
            conversation.clear()   # single-turn: discard after each exchange

        print()


# ─────────────────────────────────────────────────────────────────────────────
# Entry point
# ─────────────────────────────────────────────────────────────────────────────

DEFAULT_SYSTEM = (
    "You are an expert Java security engineer specialising in vulnerability remediation. "
    "When asked to fix vulnerable Java code, produce a corrected, secure version inside "
    "a ```java ... ``` code block. Be concise and precise."
)

def main():
    parser = argparse.ArgumentParser(
        description="CLI chat client for a vLLM-served model",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    parser.add_argument(
        "--url",
        default=os.environ.get("VLLM_BASE_URL", "http://localhost:8000"),
        help="vLLM server base URL (default: http://localhost:8000 or $VLLM_BASE_URL)",
    )
    parser.add_argument(
        "--backend",
        choices=["auto", "openai", "ollama"],
        default="auto",
        help="API backend mode: auto, openai, or ollama (default: auto)",
    )
    parser.add_argument(
        "--model",
        default=os.environ.get("VLLM_MODEL", ""),
        help="Model name to use (default: auto-detect first available model)",
    )
    parser.add_argument(
        "--system",
        default=DEFAULT_SYSTEM,
        help="System prompt (default: Java security expert)",
    )
    parser.add_argument(
        "--no-system",
        action="store_true",
        help="Do not send any system prompt",
    )
    parser.add_argument(
        "--temperature", "-t",
        type=float,
        default=0.4,
        help="Sampling temperature 0.0–2.0 (default: 0.4)",
    )
    parser.add_argument(
        "--max-tokens", "-n",
        type=int,
        default=2048,
        help="Max tokens per response (default: 2048)",
    )
    parser.add_argument(
        "--stream",
        action="store_true",
        help="Enable streaming output (tokens printed as generated)",
    )
    parser.add_argument(
        "--no-history",
        action="store_true",
        help="Disable conversation history (single-turn mode)",
    )
    parser.add_argument(
        "--api-key",
        default=os.environ.get("VLLM_API_KEY", ""),
        help="API key if server requires authentication ($VLLM_API_KEY)",
    )

    args = parser.parse_args()

    # Auto-detect model if not specified
    model = args.model
    if not model:
        models = _get_models(args.url, args.api_key, args.backend)
        if models:
            model = models[0]
            print(dim(f"Auto-detected model: {model}"))
        else:
            model = "default"
            print(yellow(f"[WARN] No model auto-detected. Using '{model}'. "
                         f"Pass --model <name> to specify."))

    system_prompt = "" if args.no_system else args.system

    chat_loop(
        base_url      = args.url,
        model         = model,
        system_prompt = system_prompt,
        temperature   = args.temperature,
        max_tokens    = args.max_tokens,
        stream        = args.stream,
        keep_history  = not args.no_history,
        api_key       = args.api_key,
        backend       = args.backend,
    )


if __name__ == "__main__":
    main()
