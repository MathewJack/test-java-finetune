"""
modelcompare-pre-post.py — Pre/post fine-tuning Java security benchmark & comparison

Tests a model on 10 classic Java vulnerability scenarios using natural developer
prompts — NO system prompt, NO special formatting. Just how a developer would
ask for help with their code.

Workflow:
  Step 1: Benchmark base model (vLLM server running):
    python modelcompare-pre-post.py \\
        --model qwen3-8b \\
        --url http://localhost:8000 \\
        --output results/base.json

  Step 2: Swap to fine-tuned model and benchmark:
    python modelcompare-pre-post.py \
        --model ./output/qwen3-java-vuln-grpo_merged_16bit/ \
        --url http://localhost:8000 \
        --output results/finetuned.json

  Step 3: Compare:
    python modelcompare-pre-post.py \
        --compare results/base.json results/finetuned.json \
        --report results/comparison_report-1.txt

  Local mode (no server needed — loads model with transformers):
    python modelcompare-pre-post.py \\
        --mode local \\
        --model unsloth/Qwen3-8B-unsloth-bnb-4bit \\
        --output results/base_local.json
"""

from __future__ import annotations

import argparse
import json
import os
import re
import sys
import time
import urllib.error
import urllib.request
from datetime import datetime
from pathlib import Path
from typing import Optional


# ─────────────────────────────────────────────────────────────────────────────
# Test cases — 10 natural developer prompts covering classic Java CWEs
# No system prompt, no formal structure — just a developer asking for help
# ─────────────────────────────────────────────────────────────────────────────

TEST_CASES = [
    {
        "id":          "TC-001",
        "cwe_id":      "CWE-089",
        "vuln_type":   "SQL Injection",
        "description": "String concatenation in JDBC query",
        "user_prompt": (
            "Hey, I wrote this Java method to look up users by email. "
            "My security scanner keeps flagging it but I'm not sure what's wrong. "
            "Can you take a look and fix it?\n\n"
            "```java\n"
            "public User findUserByEmail(String email) {\n"
            "    String sql = \"SELECT * FROM users WHERE email = '\" + email + \"'\";\n"
            "    return jdbcTemplate.queryForObject(sql, new UserRowMapper());\n"
            "}\n"
            "```"
        ),
        "safe_apis":     ["PreparedStatement", r"setString\s*\(", r"\?"],
        "vuln_patterns": [r'"\s*\+\s*email\s*\+\s*"', r"email\s*\+"],
    },
    {
        "id":          "TC-002",
        "cwe_id":      "CWE-022",
        "vuln_type":   "Path Traversal",
        "description": "Unsanitised filename parameter used for file access",
        "user_prompt": (
            "I'm building a file download endpoint. It works fine, "
            "but my tech lead says there's a path traversal issue. "
            "What's wrong and how do I fix it?\n\n"
            "```java\n"
            "public void downloadFile(HttpServletRequest req,\n"
            "                         HttpServletResponse resp) throws IOException {\n"
            "    String filename = req.getParameter(\"file\");\n"
            "    File file = new File(\"/var/uploads/\" + filename);\n"
            "    Files.copy(file.toPath(), resp.getOutputStream());\n"
            "}\n"
            "```"
        ),
        "safe_apis":     [r"normalize\(\)", r"Paths\.get\(", r"startsWith\(", r"toRealPath"],
        "vuln_patterns": [r'new File\(.*\+\s*filename', r'"/.*"\s*\+\s*filename'],
    },
    {
        "id":          "TC-003",
        "cwe_id":      "CWE-078",
        "vuln_type":   "OS Command Injection",
        "description": "User input passed directly to Runtime.exec()",
        "user_prompt": (
            "This utility pings a host to check if it's reachable. "
            "A coworker said it's dangerous but I don't see why. Can you explain and fix it?\n\n"
            "```java\n"
            "public String pingHost(String hostname) throws IOException {\n"
            "    Process proc = Runtime.getRuntime().exec(\"ping -c 1 \" + hostname);\n"
            "    try (BufferedReader br = new BufferedReader(\n"
            "            new InputStreamReader(proc.getInputStream()))) {\n"
            "        return br.lines().collect(Collectors.joining(\"\\n\"));\n"
            "    }\n"
            "}\n"
            "```"
        ),
        "safe_apis":     ["ProcessBuilder", r"Arrays\.asList\(", r"allowlist", r"whitelist", r"matches\("],
        "vuln_patterns": [r'exec\(.*\+\s*hostname', r"getRuntime\(\)\.exec\("],
    },
    {
        "id":          "TC-004",
        "cwe_id":      "CWE-611",
        "vuln_type":   "XML External Entity (XXE)",
        "description": "Default DocumentBuilder allows external entity processing",
        "user_prompt": (
            "I parse XML from user submissions with this code. "
            "OWASP says DocumentBuilderFactory can be exploited for XXE attacks. "
            "Can you make it safe?\n\n"
            "```java\n"
            "public Document parseXml(InputStream xmlInput) throws Exception {\n"
            "    DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();\n"
            "    DocumentBuilder builder = factory.newDocumentBuilder();\n"
            "    return builder.parse(xmlInput);\n"
            "}\n"
            "```"
        ),
        "safe_apis":     [r"setFeature\(", r"external-general-entities", r"disallow-doctype-decl",
                          r"FEATURE_SECURE_PROCESSING"],
        "vuln_patterns": [r"newInstance\(\)\s*;\s*\n\s*DocumentBuilder builder = factory\.newDocumentBuilder\(\)\s*;\s*\n\s*return"],
    },
    {
        "id":          "TC-005",
        "cwe_id":      "CWE-502",
        "vuln_type":   "Insecure Deserialization",
        "description": "ObjectInputStream deserialises untrusted data without validation",
        "user_prompt": (
            "Our app deserialises objects received over the network. "
            "The pentest report says this is a critical security flaw. How do I fix it?\n\n"
            "```java\n"
            "public Object deserializeFromStream(InputStream is) throws Exception {\n"
            "    ObjectInputStream ois = new ObjectInputStream(is);\n"
            "    return ois.readObject();\n"
            "}\n"
            "```"
        ),
        "safe_apis":     [r"ValidatingObjectInputStream", r"ObjectInputFilter", r"createFilter",
                          r"Jackson", r"Gson", r"JSON", r"ObjectInputFilter\.Config"],
        "vuln_patterns": [r"new ObjectInputStream\(is\)", r"new ObjectInputStream\("],
    },
    {
        "id":          "TC-006",
        "cwe_id":      "CWE-327",
        "vuln_type":   "Weak Cryptographic Algorithm",
        "description": "MD5 used for password hashing",
        "user_prompt": (
            "I'm hashing user passwords before storing them in the DB. "
            "I heard MD5 is insecure — what should I use instead? "
            "Can you update this code?\n\n"
            "```java\n"
            "public String hashPassword(String password) throws NoSuchAlgorithmException {\n"
            "    MessageDigest md = MessageDigest.getInstance(\"MD5\");\n"
            "    byte[] hash = md.digest(password.getBytes());\n"
            "    return Base64.getEncoder().encodeToString(hash);\n"
            "}\n"
            "```"
        ),
        "safe_apis":     [r"BCrypt", r"Argon2", r"PBKDF2WithHmacSHA", r"SCrypt",
                          r"bcrypt", r"SHA-256", r"SHA-512"],
        "vuln_patterns": [r'getInstance\("MD5"\)', r'getInstance\("SHA-1"\)'],
    },
    {
        "id":          "TC-007",
        "cwe_id":      "CWE-330",
        "vuln_type":   "Use of Insufficiently Random Values",
        "description": "java.util.Random used for security-sensitive token generation",
        "user_prompt": (
            "I generate password reset tokens like this, "
            "but code review says I should use a 'secure' random. "
            "What's the difference and how do I fix it?\n\n"
            "```java\n"
            "public String generateResetToken() {\n"
            "    Random random = new Random();\n"
            "    byte[] bytes = new byte[32];\n"
            "    random.nextBytes(bytes);\n"
            "    return Base64.getUrlEncoder().encodeToString(bytes);\n"
            "}\n"
            "```"
        ),
        "safe_apis":     [r"SecureRandom", r"new SecureRandom"],
        "vuln_patterns": [r"new Random\(\)", r"new java\.util\.Random"],
    },
    {
        "id":          "TC-008",
        "cwe_id":      "CWE-090",
        "vuln_type":   "LDAP Injection",
        "description": "Unsanitised input in LDAP search filter",
        "user_prompt": (
            "We use Active Directory for authentication. "
            "Can you check if this lookup code has any security issues?\n\n"
            "```java\n"
            "public boolean authenticateUser(String username, String password)\n"
            "        throws NamingException {\n"
            "    String filter = \"(&(objectClass=user)(sAMAccountName=\" + username + \"))\";\n"
            "    NamingEnumeration<?> results = ctx.search(\"dc=company,dc=com\",\n"
            "                                              filter, controls);\n"
            "    return results.hasMore();\n"
            "}\n"
            "```"
        ),
        "safe_apis":     [r"escapeLDAPSearchFilter", r"encodeForLDAP", r"ESAPI",
                          r"replace\(", r"Pattern\.", r"whitelist", r"allowlist"],
        "vuln_patterns": [r'filter.*\+.*username', r'sAMAccountName="\s*\+'],
    },
    {
        "id":          "TC-009",
        "cwe_id":      "CWE-918",
        "vuln_type":   "Server-Side Request Forgery (SSRF)",
        "description": "User-controlled URL used directly for outbound HTTP request",
        "user_prompt": (
            "I'm building a webhook feature — our app calls back to a URL the user provides. "
            "The security team flagged it as SSRF. How do I fix this?\n\n"
            "```java\n"
            "public String callWebhook(String webhookUrl, String payload)\n"
            "        throws IOException {\n"
            "    URL url = new URL(webhookUrl);\n"
            "    HttpURLConnection conn = (HttpURLConnection) url.openConnection();\n"
            "    conn.setRequestMethod(\"POST\");\n"
            "    conn.setDoOutput(true);\n"
            "    try (OutputStream os = conn.getOutputStream()) {\n"
            "        os.write(payload.getBytes());\n"
            "    }\n"
            "    return String.valueOf(conn.getResponseCode());\n"
            "}\n"
            "```"
        ),
        "safe_apis":     [r"allowlist", r"whitelist", r"InetAddress", r"getHost\(\)",
                          r"startsWith.*https://", r"validate", r"Pattern\.matches"],
        "vuln_patterns": [r"new URL\(webhookUrl\)", r"URL\(.*webhookUrl"],
    },
    {
        "id":          "TC-010",
        "cwe_id":      "CWE-079",
        "vuln_type":   "Cross-Site Scripting (XSS)",
        "description": "Unsanitised user input reflected directly into HTML response",
        "user_prompt": (
            "I have a search page that echoes the query back to the user. "
            "My colleague mentioned something about XSS. "
            "Is there a problem, and if so, how do I fix it?\n\n"
            "```java\n"
            "public void handleSearch(HttpServletRequest req,\n"
            "                          HttpServletResponse resp) throws IOException {\n"
            "    String query = req.getParameter(\"q\");\n"
            "    resp.setContentType(\"text/html\");\n"
            "    PrintWriter out = resp.getWriter();\n"
            "    out.println(\"<h2>Results for: \" + query + \"</h2>\");\n"
            "}\n"
            "```"
        ),
        "safe_apis":     [r"HtmlUtils\.htmlEscape", r"StringEscapeUtils", r"escapeHtml",
                          r"ESAPI", r"Encode\.forHtml", r"encode\("],
        "vuln_patterns": [r'println\(.*\+\s*query', r'".*"\s*\+\s*query\s*\+'],
    },
]


# ─────────────────────────────────────────────────────────────────────────────
# Scoring  (0-10 per test case)
# ─────────────────────────────────────────────────────────────────────────────

MATCH_CODE_BLOCK = re.compile(r'```(\w+)?\s*([\s\S]+?)```', re.DOTALL)
MATCH_JAVA_BLOCK = re.compile(r'```java\s*([\s\S]+?)```', re.DOTALL)


def score_response(tc: dict, response: str) -> dict:
    java_m  = MATCH_JAVA_BLOCK.search(response)
    code_m  = MATCH_CODE_BLOCK.search(response)
    # MATCH_JAVA_BLOCK has one capture group; MATCH_CODE_BLOCK has two.
    java_code = (java_m.group(1) if java_m else (code_m.group(2) if code_m else response)).strip()

    score = 0
    d: dict = {}

    # +1  any code block present
    d["has_code_block"] = bool(code_m)
    if d["has_code_block"]:
        score += 1

    # +1  specifically java block
    d["has_java_block"] = bool(java_m)
    if d["has_java_block"]:
        score += 1

    # +3  vulnerable pattern removed from output code
    vuln_hits = sum(1 for p in tc["vuln_patterns"]
                    if re.search(p, java_code, re.IGNORECASE))
    d["vuln_patterns_still_present"] = vuln_hits
    d["vuln_patterns_removed"]       = len(tc["vuln_patterns"]) - vuln_hits
    if vuln_hits == 0 and java_code:
        score += 3
    elif vuln_hits < len(tc["vuln_patterns"]):
        score += 1  # partial credit

    # +3  safe API used in the fix (capped at 3)
    safe_hits = sum(1 for p in tc["safe_apis"]
                    if re.search(p, java_code, re.IGNORECASE))
    d["safe_apis_found"] = safe_hits
    score += min(safe_hits, 3)

    # +2  vulnerability type mentioned in the response (model awareness)
    keywords = [w for w in tc["vuln_type"].lower().split() if len(w) > 3]
    d["vulnerability_mentioned"] = any(kw in response.lower() for kw in keywords)
    if d["vulnerability_mentioned"]:
        score += 2

    d["score"]     = min(score, 10)
    d["max_score"] = 10
    return d


# ─────────────────────────────────────────────────────────────────────────────
# Inference helpers
# ─────────────────────────────────────────────────────────────────────────────

def _call_vllm(base_url: str, model: str, prompt: str,
               max_tokens: int = 1024, temperature: float = 0.3,
               api_key: str = "") -> tuple[str, float, int]:
    """Call vLLM /v1/chat/completions with NO system prompt."""
    url     = f"{base_url.rstrip('/')}/v1/chat/completions"
    payload = json.dumps({
        "model":       model,
        "messages":    [{"role": "user", "content": prompt}],
        "temperature": temperature,
        "max_tokens":  max_tokens,
    }).encode()
    headers = {"Content-Type": "application/json", "Accept": "application/json"}
    if api_key:
        headers["Authorization"] = f"Bearer {api_key}"

    req = urllib.request.Request(url, data=payload, headers=headers, method="POST")
    t0  = time.time()
    try:
        with urllib.request.urlopen(req, timeout=300) as resp:
            latency_ms = (time.time() - t0) * 1000
            data   = json.loads(resp.read().decode())
            text   = data["choices"][0]["message"]["content"]
            tokens = data.get("usage", {}).get("completion_tokens", len(text.split()))
            return text, latency_ms, tokens
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", errors="ignore")
        raise RuntimeError(f"HTTP {e.code}: {body[:200]}")
    except urllib.error.URLError as e:
        raise RuntimeError(f"Cannot reach {url}: {e.reason}")


def _call_local(model_path: str, prompt: str,
                max_tokens: int = 1024,
                temperature: float = 0.3) -> tuple[str, float, int]:
    """Load model locally and run inference (no server required)."""
    import gc
    import torch
    from transformers import AutoModelForCausalLM, AutoTokenizer

    print(f"  Loading model locally: {model_path} ...")
    tok = AutoTokenizer.from_pretrained(model_path, trust_remote_code=True)
    mdl = AutoModelForCausalLM.from_pretrained(
        model_path,
        torch_dtype       = torch.bfloat16,
        device_map        = "auto",
        trust_remote_code = True,
    )
    mdl.eval()

    try:
        text_in = tok.apply_chat_template(
            [{"role": "user", "content": prompt}],
            tokenize=False, add_generation_prompt=True,
        )
    except Exception:
        text_in = prompt

    inputs   = tok(text_in, return_tensors="pt").to(mdl.device)
    n_in     = inputs["input_ids"].shape[1]
    t0       = time.time()
    with torch.no_grad():
        outputs = mdl.generate(
            **inputs,
            max_new_tokens = max_tokens,
            temperature    = temperature,
            do_sample      = True,
            pad_token_id   = tok.eos_token_id,
        )
    latency_ms = (time.time() - t0) * 1000
    n_out      = outputs.shape[1] - n_in
    generated  = tok.decode(outputs[0][n_in:], skip_special_tokens=True)

    del mdl, tok
    gc.collect()
    if torch.cuda.is_available():
        torch.cuda.empty_cache()

    return generated, latency_ms, n_out


# ─────────────────────────────────────────────────────────────────────────────
# Run benchmark
# ─────────────────────────────────────────────────────────────────────────────

def run_benchmark(
    model:       str,
    output_path: str,
    mode:        str   = "api",
    base_url:    str   = "http://localhost:8000",
    api_key:     str   = "",
    max_tokens:  int   = 1024,
    temperature: float = 0.3,
):
    results = []
    print(f"\n{'='*65}")
    print(f"  Benchmarking: {model}")
    print(f"  Mode: {mode}  |  Output: {output_path}")
    print(f"{'='*65}\n")

    for tc in TEST_CASES:
        print(f"  [{tc['id']}] {tc['cwe_id']} — {tc['vuln_type']}")
        print(f"         {tc['description']}")
        try:
            if mode == "api":
                response, latency_ms, n_tok = _call_vllm(
                    base_url, model, tc["user_prompt"],
                    max_tokens, temperature, api_key,
                )
            else:
                response, latency_ms, n_tok = _call_local(
                    model, tc["user_prompt"], max_tokens, temperature,
                )

            tok_per_sec = n_tok / (latency_ms / 1000) if latency_ms > 0 else 0
            scoring     = score_response(tc, response)

            print(f"         Score: {scoring['score']:2d}/10 | "
                  f"Latency: {latency_ms:6.0f}ms | "
                  f"Throughput: {tok_per_sec:5.1f} tok/s")
            print(f"         Safe APIs: {scoring['safe_apis_found']} | "
                  f"Vuln removed: {scoring['vuln_patterns_removed']}/{len(tc['vuln_patterns'])} | "
                  f"Mentioned CWE: {scoring['vulnerability_mentioned']}")

            results.append({
                "test_id":          tc["id"],
                "cwe_id":           tc["cwe_id"],
                "vuln_type":        tc["vuln_type"],
                "description":      tc["description"],
                "input_prompt":     tc["user_prompt"],
                "model_output":     response,
                "latency_ms":       round(latency_ms, 1),
                "tokens_generated": n_tok,
                "tokens_per_sec":   round(tok_per_sec, 1),
                "scoring":          scoring,
                "timestamp":        datetime.now().isoformat(),
                "model_name":       model,
            })

        except Exception as e:
            print(f"         [ERROR] {e}")
            results.append({
                "test_id":          tc["id"],
                "cwe_id":           tc["cwe_id"],
                "vuln_type":        tc["vuln_type"],
                "description":      tc["description"],
                "input_prompt":     tc["user_prompt"],
                "model_output":     f"ERROR: {e}",
                "latency_ms":       -1,
                "tokens_generated": 0,
                "tokens_per_sec":   0,
                "scoring":          {"score": 0, "max_score": 10},
                "timestamp":        datetime.now().isoformat(),
                "model_name":       model,
            })

    avg_score  = sum(r["scoring"]["score"] for r in results) / len(results)
    avg_lat    = sum(r["latency_ms"] for r in results if r["latency_ms"] > 0)
    n_valid    = sum(1 for r in results if r["latency_ms"] > 0)
    avg_lat   /= max(n_valid, 1)
    avg_tps    = sum(r["tokens_per_sec"] for r in results if r["tokens_per_sec"] > 0)
    avg_tps   /= max(n_valid, 1)

    Path(output_path).parent.mkdir(parents=True, exist_ok=True)
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump({
            "model":             model,
            "mode":              mode,
            "timestamp":         datetime.now().isoformat(),
            "avg_score":         round(avg_score, 2),
            "avg_latency_ms":    round(avg_lat, 1),
            "avg_tokens_per_sec": round(avg_tps, 1),
            "results":           results,
        }, f, indent=2, ensure_ascii=False)

    print(f"\n{'='*65}")
    print(f"  Average score:      {avg_score:.1f} / 10")
    print(f"  Average latency:    {avg_lat:.0f} ms")
    print(f"  Average throughput: {avg_tps:.1f} tok/s")
    print(f"  Results saved to:   {output_path}")
    print(f"{'='*65}")


# ─────────────────────────────────────────────────────────────────────────────
# Comparison
# ─────────────────────────────────────────────────────────────────────────────

def compare_results(file_a: str, file_b: str,
                    report_path: Optional[str] = None):
    """Load two benchmark files and produce a side-by-side comparison report."""
    with open(file_a, encoding="utf-8") as f:
        data_a = json.load(f)
    with open(file_b, encoding="utf-8") as f:
        data_b = json.load(f)

    r_a = {r["test_id"]: r for r in data_a["results"]}
    r_b = {r["test_id"]: r for r in data_b["results"]}
    ids = sorted(set(r_a) | set(r_b))

    lines = []
    W = 70

    def h(title=""):
        lines.append("=" * W)
        if title:
            lines.append(f"  {title}")
            lines.append("=" * W)

    h("JAVA SECURITY MODEL COMPARISON REPORT")
    lines.append(f"  Base model:        {data_a['model']}")
    lines.append(f"  Fine-tuned model:  {data_b['model']}")
    lines.append(f"  Generated:         {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    h()

    # ── Per-test table ───────────────────────────────────────────────────────
    lines.append(f"\n  {'ID':<8} {'Vulnerability':<30} {'Base':>5} {'FT':>5}"
                 f" {'Δ':>5}  {'Lat A':>7} {'Lat B':>7} {'Lat Δ':>7}")
    lines.append("  " + "-" * (W - 2))

    improved = regressed = unchanged = 0
    score_deltas = []

    for tid in ids:
        ra = r_a.get(tid)
        rb = r_b.get(tid)
        if not ra or not rb:
            continue
        sa  = ra["scoring"]["score"]
        sb  = rb["scoring"]["score"]
        d   = sb - sa
        score_deltas.append(d)
        la  = ra["latency_ms"]
        lb  = rb["latency_ms"]
        ld  = lb - la if la > 0 and lb > 0 else 0

        if d > 0:   improved  += 1; arrow = "▲"
        elif d < 0: regressed += 1; arrow = "▼"
        else:       unchanged += 1; arrow = "─"

        vt = ra["vuln_type"][:28]
        la_s = f"{la:.0f}ms" if la > 0 else "ERR"
        lb_s = f"{lb:.0f}ms" if lb > 0 else "ERR"
        ld_s = f"{ld:+.0f}ms" if ld != 0 else "same"
        lines.append(f"  {tid:<8} {vt:<30} {sa:>5.1f} {sb:>5.1f}"
                     f" {d:>+4.1f}{arrow}  {la_s:>7} {lb_s:>7} {ld_s:>7}")

    avg_a   = data_a.get("avg_score", 0)
    avg_b   = data_b.get("avg_score", 0)
    avg_d   = avg_b - avg_a
    lat_a   = data_a.get("avg_latency_ms", 0)
    lat_b   = data_b.get("avg_latency_ms", 0)
    tps_a   = data_a.get("avg_tokens_per_sec", 0)
    tps_b   = data_b.get("avg_tokens_per_sec", 0)

    lines.append("  " + "-" * (W - 2))
    lines.append(f"  {'AVERAGE':<39} {avg_a:>5.1f} {avg_b:>5.1f} {avg_d:>+5.1f}")
    lines.append("")

    # ── Summary ──────────────────────────────────────────────────────────────
    lines.append("  Summary:")
    lines.append(f"    Improved test cases:  {improved} / {len(ids)}")
    lines.append(f"    Regressed test cases: {regressed} / {len(ids)}")
    lines.append(f"    Unchanged:            {unchanged} / {len(ids)}")
    lines.append(f"    Average score gain:   {avg_d:+.2f} pts"
                 f"  ({avg_d / 10 * 100:+.1f}% of max)")
    lines.append(f"    Avg latency  base:    {lat_a:.0f} ms"
                 f"  vs fine-tuned: {lat_b:.0f} ms  ({lat_b - lat_a:+.0f} ms)")
    lines.append(f"    Avg throughput base:  {tps_a:.1f} tok/s"
                 f"  vs fine-tuned: {tps_b:.1f} tok/s")
    lines.append("")

    # ── Verdict ──────────────────────────────────────────────────────────────
    lines.append("  Verdict:")
    if avg_d >= 3:
        lines.append("    ✅ SIGNIFICANT IMPROVEMENT — fine-tuning was highly effective.")
    elif avg_d >= 1:
        lines.append("    ✅ MODERATE IMPROVEMENT — fine-tuning shows measurable gains.")
    elif avg_d >= 0:
        lines.append("    ⚠️  MARGINAL IMPROVEMENT — minimal effect. Consider more training "
                     "steps or a larger/better dataset.")
    else:
        lines.append("    ❌ REGRESSION — fine-tuned model performs worse. "
                     "Review reward functions and training stability.")
    lines.append("")

    # ── Per-test detail ───────────────────────────────────────────────────────
    h("DETAILED OUTPUTS")
    for tid in ids:
        ra = r_a.get(tid)
        rb = r_b.get(tid)
        if not ra or not rb:
            continue
        sa = ra["scoring"]["score"]
        sb = rb["scoring"]["score"]
        lines.append(f"\n  [{tid}] {ra['cwe_id']} — {ra['vuln_type']}")
        lines.append(f"  Score: base={sa}/10   fine-tuned={sb}/10   Δ={sb - sa:+.0f}")
        lines.append(f"  Prompt (first 200 chars):")
        lines.append(f"    {ra['input_prompt'][:200].replace(chr(10), ' ')}")
        lines.append(f"  Base model output (first 400 chars):")
        lines.append(f"    {ra['model_output'][:400].replace(chr(10), ' ')}")
        lines.append(f"  Fine-tuned output (first 400 chars):")
        lines.append(f"    {rb['model_output'][:400].replace(chr(10), ' ')}")
        lines.append(f"  Base  — safe APIs: {ra['scoring'].get('safe_apis_found', 0)}"
                     f"  vuln removed: {ra['scoring'].get('vuln_patterns_removed', '?')}")
        lines.append(f"  FT    — safe APIs: {rb['scoring'].get('safe_apis_found', 0)}"
                     f"  vuln removed: {rb['scoring'].get('vuln_patterns_removed', '?')}")

    lines.append("")
    h()

    report_text = "\n".join(lines)
    print(report_text)

    if report_path:
        Path(report_path).parent.mkdir(parents=True, exist_ok=True)
        with open(report_path, "w", encoding="utf-8") as f:
            f.write(report_text)
            f.write("\n\n--- FULL JSON ---\n")
            for tid in ids:
                ra = r_a.get(tid)
                rb = r_b.get(tid)
                if ra and rb:
                    f.write(f"\n[{tid}] BASE:\n{json.dumps(ra, indent=2)}\n")
                    f.write(f"\n[{tid}] FINE-TUNED:\n{json.dumps(rb, indent=2)}\n")
        print(f"\nFull report saved to: {report_path}")


# ─────────────────────────────────────────────────────────────────────────────
# Entry point
# ─────────────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description="Benchmark and compare base vs fine-tuned model on Java security tasks",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    parser.add_argument("--model",   default="",
                        help="Model name (API mode) or path (local mode)")
    parser.add_argument("--url",     default=os.environ.get("VLLM_BASE_URL", "http://localhost:8000"),
                        help="vLLM server base URL (default: http://localhost:8000 or $VLLM_BASE_URL)")
    parser.add_argument("--mode",    choices=["api", "local"], default="api",
                        help="'api' uses vLLM server; 'local' loads model directly")
    parser.add_argument("--output",  default="",
                        help="Output JSON file for benchmark results")
    parser.add_argument("--compare", nargs=2, metavar=("BASE_JSON", "FINETUNED_JSON"),
                        help="Compare two result files")
    parser.add_argument("--report",  default="",
                        help="Save comparison report to this file")
    parser.add_argument("--max-tokens",  type=int,   default=1024)
    parser.add_argument("--temperature", type=float, default=0.3)
    parser.add_argument("--api-key", default=os.environ.get("VLLM_API_KEY", ""))
    args = parser.parse_args()

    if args.compare:
        compare_results(args.compare[0], args.compare[1],
                        report_path=args.report or None)
        return

    if not args.model:
        parser.error("--model is required when not using --compare")
    if not args.output:
        parser.error("--output is required when not using --compare")

    run_benchmark(
        model       = args.model,
        output_path = args.output,
        mode        = args.mode,
        base_url    = args.url,
        api_key     = args.api_key,
        max_tokens  = args.max_tokens,
        temperature = args.temperature,
    )


if __name__ == "__main__":
    main()
